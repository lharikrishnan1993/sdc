
Sample command to generate executable
g++ -std=c++11 cv_team.cpp -o [output_file_name]

Points to note
Make sure you use C++11. Else, it would fail for sure.
